package com.example.menuka.adaptertest;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private List<Person> personList;
    private PersonAdapter personAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        personList = new ArrayList<>();
        personList.add(new Person("Mark", "21"));
        personList.add(new Person("John", "22"));
        personList.add(new Person("Oliver", "28"));
        personList.add(new Person("Tom", "27"));
        personList.add(new Person("Francis", "30"));

        personAdapter = new PersonAdapter(this, 0, personList);

        ListView listView = (ListView) findViewById(R.id.names_list_view);
        listView.setAdapter(personAdapter);
    }
}
